# pylint: disable=invalid-name
#!/usr/bin/env python3

"""
Configuration Module
"""

_UNIGENE_DIR = "./data_directories"
_UNIGENE_FILE_ENDING = "unigene"


def get_unigene_directory():
    """
    Get Unigene Directory
    """
    return _UNIGENE_DIR


def get_uigene_extension():
    """
    Get Unigene Extension
    """
    return _UNIGENE_FILE_ENDING


def get_host_keywords():
    """
    Get Host Keywords
    """
    bos_tarus = "Bos_taurus"
    homo_sapiens = "Homo_sapiens"
    equus_caballus = "Equus_caballus"
    mus_musculus = "Mus_musculus"
    ovis_aries = "Ovis_aries"
    rattus_norvegicus = "Rattus_norvegicus"
    host_keywords = {
        "bos taurus": bos_tarus,
        "cow": bos_tarus,
        "cows": bos_tarus,
        "homo sapiens": homo_sapiens,
        "human": homo_sapiens,
        "humans": homo_sapiens,
        "equus caballus": equus_caballus,
        "horse": equus_caballus,
        "horses": equus_caballus,
        "mus_musculus": mus_musculus,
        "mouse": mus_musculus,
        "mice": mus_musculus,
        "ovis_aries": ovis_aries,
        "sheep": ovis_aries,
        "sheeps": ovis_aries,
        "rattus_norvegicus": rattus_norvegicus,
        "rat": rattus_norvegicus,
        "rats": rattus_norvegicus
    }
    return host_keywords


def get_error_string_4_ioerror(file, mode):
    """ I/O Error """
    print(f"IOError: Could not open the file: {file} for type '{mode}'")


def get_error_string_4_valueerror():  
    """ File Value Error """
    print("There is something wrong with the value of the file provided")


def get_error_string_4_typeerror():  
    """ File Type Error """
    print("There is something wrong with the type of file provided")
