#!/usr/bin/env python3


"""
This module helps with I/O operations

Funtions provided are:
get_fh: executes file operation on the given file in the given mode
"""
import os


def get_fh(input_file_name, open_mode):
    """
    File Handler Function with error handling
    """
    try:
        return open(input_file_name, open_mode, encoding="utf8")
    except ValueError as error:
        raise ValueError('Invalid mode:', open_mode) from error
    except IOError as error:
        raise IOError('File could not be opened') from error


def is_valid_gene_file_name(file):
    """ Check if the given file name exists """
    return bool(os.path.exists(file))
