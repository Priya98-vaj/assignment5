# pylint: disable=inconsistent-return-statements
#!/usr/bin/env python3

"""
Tissue Expression Query
"""

import argparse
import sys
import re
from assignment5 import config
from assignment5 import my_io


def get_cli_args():
    """ Get Comman Line Arguments """
    parser = argparse.ArgumentParser()
    parser.add_argument('-host', dest='HOST',
                        help='Please specify species name', required=False)
    parser.add_argument('-gene', dest='GENE',
                        help='Please specify gene name', required=False)
    return parser.parse_args()


def __print_scientific_name():
    """ Print Scientific Names """
    hosts = config.get_host_keywords()
    names = hosts.values()
    print("\nHere is a (non-case sensitive) list of available Hosts by scientific name\n")
    list_names = tuple(enumerate(set(names), 1))
    for index, name in list_names:
        print("{:>2}. {}".format(index, name.capitalize()))


def __print_common_name():
    """ Print Common Names"""
    hosts = config.get_host_keywords()
    names = hosts.keys()
    print("\nHere is a (non-case sensitive) list of available Hosts by common name\n")
    list_names = tuple(enumerate(sorted(set(names)), 1))
    for index, name in list_names:
        print("{:>2}. {}".format(index, name.capitalize()))


def __print_host_directories():
    print('\nEither the Host Name you are searching for is not in the database\n\n\
or If you are trying to use the scientific name please put the name in double quotes:\n\n\
"Scientific name"')
    __print_scientific_name()
    __print_common_name()


def modify_host_name(host):
    """ 
    Modify Hostname
    """
    keyword_dict = config.get_host_keywords()  
    if host in keyword_dict.keys():
        return keyword_dict.get(host)

    __print_host_directories()
    sys.exit()



def get_gene_data(host_name, gene_name):
    """
    Get Gene Data
    """
    print(sys.exc_info()[2])
    file = "/".join((config.get_unigene_directory(),
                     host_name, gene_name + "." + config.get_uigene_extension()))

    if my_io.is_valid_gene_file_name(file):
        # using f-strings
        message = f"\nFound Gene {gene_name} for {host_name}"
    else:
        print(f"Not found\n Gene {gene_name} does not exist for {host_name}. exiting now...")
        sys.exit()

    fh_in = my_io.get_fh(file, "r")
    for line in fh_in:
        match = re.search(r'^EXPRESS\s+(\D+)', line)
        if match:
            tissue_string = match.group(1)
            temp_tissue_list = list(tissue_string.split(sep='|'))
            tissue_list = sorted([tissue.strip()
                                 for tissue in temp_tissue_list])
            return message, tissue_list


def print_output(host_name, gene_name, tissue_list):       
    """ 
    Output format and print
    """
    tissues_number = len(tissue_list)
    print(f"In {host_name}, There are {tissues_number} tissues that {gene_name} is expressed in:\n")
    for index, tissue in sorted(enumerate(tissue_list, 1)):
        print(f"{index:>2}. {tissue.capitalize()} ")


def main():
    """ Business Logic """
    argvs = get_cli_args()
    temp_host_name = argvs.HOST.lower() if argvs.HOST is not None else "Homo_sapiens"
    temp_gene_name = argvs.GENE if argvs.GENE is not None else "TGM1"

    host_name = modify_host_name(temp_host_name)
    print(host_name)

    message, tissue_list = get_gene_data(temp_host_name, temp_gene_name)
    print(message)

    print_output(host_name, temp_gene_name, tissue_list)

if __name__ == '__main__':
    main()
