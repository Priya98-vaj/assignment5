#!/usr/bin/python3

"""
Test suite for my_io.py
"""
import os
import pytest
from assignment5.my_io import get_fh

# pylint: disable=C0116
# pylint: disable=C0103

FILE = 'chr21_genes.txt'


def test_get_fh_reading():
    fh = get_fh(FILE, 'r')
    assert hasattr(fh, 'readline') is True, 'problem with get_fh read'


def test_get_fh_wrting():
    with get_fh('out.txt', 'w') as fh:
        assert hasattr(fh, 'write') is True, 'problem with get_fh write'
    os.remove('out.txt')


def test_get_fh_IOError():
    with pytest.raises(IOError):
        get_fh('junk.txt', 'r')


def test_get_fh_ValueError():
    with pytest.raises(ValueError):
        get_fh('wrong_open_mode.txt', 'rrr')
