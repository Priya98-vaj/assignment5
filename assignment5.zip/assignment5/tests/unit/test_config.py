#!/usr/bin/env python3

"""Test suite for config.py"""

from assignment5 import config

# ignore all "Missing function or method docstring" since this is a unit test
# pylint: disable=C0116
# ignore all "Function name "test_get_fh_4_IOError" doesn't conform to snake_case naming style"
# pylint: disable=C0103


def test_get_error_string_4_ioerror(capfd):
    config.get_error_string_4_ioerror("test.txt", "r")
    out, _ = capfd.readouterr()
    assert out == "IOError: Could not open the file: test.txt for type 'r'\n"


def test_get_error_string_4_valueerror(capfd):
    config.get_error_string_4_valueerror()
    out, _ = capfd.readouterr()
    assert out == "There is something wrong with the value of the file provided\n"


def test_get_error_string_4_typeerror(capfd):
    config.get_error_string_4_typeerror()
    out, _ = capfd.readouterr()
    assert out == "There is something wrong with the type of file provided\n"


def test_get_file_keywords():
    test = config.get_host_keywords()
    assert test.get("human") == "homo_sapiens"
    assert len(test.keys()) == 18
    